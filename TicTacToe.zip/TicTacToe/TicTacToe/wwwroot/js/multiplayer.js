﻿// Game state variables
let board = [
    ["", "", ""],
    ["", "", ""],
    ["", "", ""],
]
let playerRole = "" // Will be assigned by the hub (X or O)
let isGameActive = true
let player1Wins = 0
let player2Wins = 0
let draws = 0

// Connect to SignalR hub
const connection = new signalR.HubConnectionBuilder()
    .withUrl("/gameHub")
    .configureLogging(signalR.LogLevel.Information)
    .build()

// Start the connection
connection
    .start()
    .then(() => {
        console.log("Connected to Game Hub")
        document.getElementById("status").textContent = "Connected! Waiting for opponent..."
    })
    .catch((err) => {
        console.error("Error connecting to SignalR Hub:", err.toString())
        document.getElementById("status").textContent = "Connection failed!"
    })

// Handle role assignment from the hub
connection.on("AssignRole", (role) => {
    playerRole = role
    console.log(`You are player ${role}`)

    if (role === "spectator") {
        document.getElementById("status").textContent = "Game is full. You are in spectator mode."
        document.getElementById("turnIndicator").textContent = "Spectating"
        return
    }

    // Update player card highlighting based on role
    if (role === "X") {
        document.getElementById("player1-card").classList.add("active-player")
        document.getElementById("player2-card").classList.remove("active-player")
        document.getElementById("status").textContent = "You are Player 1 (X)"
        document.getElementById("turnIndicator").textContent = "Your turn"
    } else {
        document.getElementById("player2-card").classList.add("active-player")
        document.getElementById("player1-card").classList.remove("active-player")
        document.getElementById("status").textContent = "You are Player 2 (O)"
        document.getElementById("turnIndicator").textContent = "Waiting for Player 1"
    }
})

// Handle receiving moves from the hub
connection.on("ReceiveMove", (row, col, player) => {
    console.log(`Received move: row=${row}, col=${col}, player=${player}`)

    // Update the board
    board[row][col] = player
    document.getElementById("board").rows[row].cells[col].textContent = player

    // Check for win or draw
    checkGameStatus()
})

// Handle turn indicator updates
connection.on("UpdateTurnIndicator", (currentPlayer) => {
    if (playerRole === "spectator") return

    if (currentPlayer === playerRole) {
        document.getElementById("turnIndicator").textContent = "Your turn"
    } else {
        document.getElementById("turnIndicator").textContent = `Waiting for Player ${currentPlayer === "X" ? "1" : "2"}`
    }
})

// Handle board reset
connection.on("ResetBoard", () => {
    resetBoardUI()
    board = [
        ["", "", ""],
        ["", "", ""],
        ["", "", ""],
    ]
    isGameActive = true

    if (playerRole === "spectator") {
        document.getElementById("status").textContent = "Game restarted. You are spectating."
    } else {
        document.getElementById("status").textContent = playerRole === "X" ? "You are Player 1 (X)" : "You are Player 2 (O)"
    }
})

// Handle opponent disconnection
connection.on("OpponentDisconnected", () => {
    document.getElementById("status").textContent = "Opponent disconnected. Waiting for new player..."
    document.getElementById("turnIndicator").textContent = "Game paused"
})

// Make a move
function makeMove(row, col) {
    // Check if it's the player's turn and the cell is empty
    if (!isGameActive || board[row][col] !== "" || playerRole !== getCurrentPlayer() || playerRole === "spectator") {
        return
    }

    // Send the move to the hub
    connection
        .invoke("SendMove", row, col, playerRole)
        .catch((err) => console.error("Error sending move:", err.toString()))
}

// Get the current player based on the board state
function getCurrentPlayer() {
    let xCount = 0
    let oCount = 0

    for (let i = 0; i < 3; i++) {
        for (let j = 0; j < 3; j++) {
            if (board[i][j] === "X") xCount++
            if (board[i][j] === "O") oCount++
        }
    }

    return xCount <= oCount ? "X" : "O"
}

// Check for win or draw
function checkGameStatus() {
    const winPatterns = [
        // Rows
        [
            [0, 0],
            [0, 1],
            [0, 2],
        ],
        [
            [1, 0],
            [1, 1],
            [1, 2],
        ],
        [
            [2, 0],
            [2, 1],
            [2, 2],
        ],
        // Columns
        [
            [0, 0],
            [1, 0],
            [2, 0],
        ],
        [
            [0, 1],
            [1, 1],
            [2, 1],
        ],
        [
            [0, 2],
            [1, 2],
            [2, 2],
        ],
        // Diagonals
        [
            [0, 0],
            [1, 1],
            [2, 2],
        ],
        [
            [0, 2],
            [1, 1],
            [2, 0],
        ],
    ]

    // Check for win
    for (const pattern of winPatterns) {
        const [a, b, c] = pattern
        if (board[a[0]][a[1]] && board[a[0]][a[1]] === board[b[0]][b[1]] && board[a[0]][a[1]] === board[c[0]][c[1]]) {
            highlightWinningCells([a, b, c])
            endGame(board[a[0]][a[1]])
            return
        }
    }

    // Check for draw
    if (board.flat().every((cell) => cell !== "")) {
        endGame("draw")
    }
}

// Highlight winning cells
function highlightWinningCells(cells) {
    for (const [row, col] of cells) {
        document.getElementById("board").rows[row].cells[col].classList.add("winning-cell")
    }
}

// End the game
function endGame(result) {
    isGameActive = false

    if (result === "draw") {
        document.getElementById("status").textContent = "Game ended in a draw!"
        draws++
        document.getElementById("draws").textContent = `Draws: ${draws}`
    } else if (result === "X") {
        document.getElementById("status").textContent = playerRole === "X" ? "You won!" : "Player 1 won!"
        player1Wins++
        document.getElementById("player1Wins").textContent = `Score: ${player1Wins}`
    } else if (result === "O") {
        document.getElementById("status").textContent = playerRole === "O" ? "You won!" : "Player 2 won!"
        player2Wins++
        document.getElementById("player2Wins").textContent = `Score: ${player2Wins}`
    }

    document.getElementById("turnIndicator").textContent = "Game Over"
}

// Reset the board UI
function resetBoardUI() {
    const cells = document.querySelectorAll("#board td")
    cells.forEach((cell) => {
        cell.textContent = ""
        cell.classList.remove("winning-cell")
    })
}

// Restart the game
function restartGame() {
    connection.invoke("RestartGame").catch((err) => console.error("Error restarting game:", err.toString()))
}

// Add CSS for active player highlighting
const style = document.createElement("style")
style.textContent = `
.active-player {
    border: 3px solid #c62828;
    box-shadow: 0 0 10px rgba(198, 40, 40, 0.5);
    transform: scale(1.05);
    transition: all 0.3s ease;
}
`
document.head.appendChild(style)