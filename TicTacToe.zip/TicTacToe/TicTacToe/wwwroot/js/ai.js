﻿// Game state variables
let board = [
    ["", "", ""],
    ["", "", ""],
    ["", "", ""],
]
const currentPlayer = "X" // Player is X, AI is O
let isGameActive = true
let playerWins = 0
let aiWins = 0
let draws = 0

// Initialize the game
function initGame() {
    document.getElementById("turnIndicator").textContent = "Your turn"
    document.getElementById("status").textContent = ""
}

// Player makes a move
function playerMove(row, col) {
    // Check if the cell is empty and the game is active
    if (!isGameActive || board[row][col] !== "") {
        return
    }

    // Update the board with player's move
    board[row][col] = "X"
    const cell = document.querySelector(`#board tr:nth-child(${row + 1}) td:nth-child(${col + 1})`)
    cell.textContent = "X"
    cell.style.pointerEvents = "none"

    // Check for win or draw
    if (checkGameStatus()) {
        return
    }

    // AI's turn
    document.getElementById("turnIndicator").textContent = "AI is thinking..."

    // Add a small delay to simulate AI "thinking"
    setTimeout(() => {
        aiMove()
    }, 500)
}

// AI makes a move
function aiMove() {
    if (!isGameActive) {
        return
    }

    // Find the best move using minimax algorithm
    const bestMove = findBestMove()

    // Update the board with AI's move
    board[bestMove.row][bestMove.col] = "O"
    const cell = document.querySelector(`#board tr:nth-child(${bestMove.row + 1}) td:nth-child(${bestMove.col + 1})`)
    cell.textContent = "O"
    cell.style.pointerEvents = "none"

    // Check for win or draw
    if (!checkGameStatus()) {
        document.getElementById("turnIndicator").textContent = "Your turn"
    }
}

// Find the best move for AI using minimax algorithm
function findBestMove() {
    let bestVal = -1000
    const bestMove = { row: -1, col: -1 }

    // Evaluate all empty cells
    for (let i = 0; i < 3; i++) {
        for (let j = 0; j < 3; j++) {
            if (board[i][j] === "") {
                // Make the move
                board[i][j] = "O"

                // Compute evaluation function
                const moveVal = minimax(board, 0, false)

                // Undo the move
                board[i][j] = ""

                // Update best move if current is better
                if (moveVal > bestVal) {
                    bestMove.row = i
                    bestMove.col = j
                    bestVal = moveVal
                }
            }
        }
    }

    return bestMove
}

// Minimax algorithm for AI decision making
function minimax(board, depth, isMaximizing) {
    // Check for terminal states
    const score = evaluate(board)

    // If Maximizer has won the game
    if (score === 10) {
        return score - depth
    }

    // If Minimizer has won the game
    if (score === -10) {
        return score + depth
    }

    // If there are no more moves and no winner
    if (!isMovesLeft(board)) {
        return 0
    }

    // Maximizer's move (AI)
    if (isMaximizing) {
        let best = -1000

        for (let i = 0; i < 3; i++) {
            for (let j = 0; j < 3; j++) {
                if (board[i][j] === "") {
                    board[i][j] = "O"
                    best = Math.max(best, minimax(board, depth + 1, !isMaximizing))
                    board[i][j] = ""
                }
            }
        }

        return best
    }
    // Minimizer's move (Player)
    else {
        let best = 1000

        for (let i = 0; i < 3; i++) {
            for (let j = 0; j < 3; j++) {
                if (board[i][j] === "") {
                    board[i][j] = "X"
                    best = Math.min(best, minimax(board, depth + 1, !isMaximizing))
                    board[i][j] = ""
                }
            }
        }

        return best
    }
}

// Check if there are moves left
function isMovesLeft(board) {
    for (let i = 0; i < 3; i++) {
        for (let j = 0; j < 3; j++) {
            if (board[i][j] === "") {
                return true
            }
        }
    }
    return false
}

// Evaluate the board for minimax
function evaluate(board) {
    // Check rows for victory
    for (let i = 0; i < 3; i++) {
        if (board[i][0] !== "" && board[i][0] === board[i][1] && board[i][1] === board[i][2]) {
            if (board[i][0] === "O") {
                return 10
            } else if (board[i][0] === "X") {
                return -10
            }
        }
    }

    // Check columns for victory
    for (let j = 0; j < 3; j++) {
        if (board[0][j] !== "" && board[0][j] === board[1][j] && board[1][j] === board[2][j]) {
            if (board[0][j] === "O") {
                return 10
            } else if (board[0][j] === "X") {
                return -10
            }
        }
    }

    // Check diagonals for victory
    if (board[0][0] !== "" && board[0][0] === board[1][1] && board[1][1] === board[2][2]) {
        if (board[0][0] === "O") {
            return 10
        } else if (board[0][0] === "X") {
            return -10
        }
    }

    if (board[0][2] !== "" && board[0][2] === board[1][1] && board[1][1] === board[2][0]) {
        if (board[0][2] === "O") {
            return 10
        } else if (board[0][2] === "X") {
            return -10
        }
    }

    // No winner
    return 0
}

// Check for win or draw
function checkGameStatus() {
    // Check rows
    for (let i = 0; i < 3; i++) {
        if (board[i][0] !== "" && board[i][0] === board[i][1] && board[i][1] === board[i][2]) {
            highlightWinningCells([
                [i, 0],
                [i, 1],
                [i, 2],
            ])
            endGame(board[i][0])
            return true
        }
    }

    // Check columns
    for (let j = 0; j < 3; j++) {
        if (board[0][j] !== "" && board[0][j] === board[1][j] && board[1][j] === board[2][j]) {
            highlightWinningCells([
                [0, j],
                [1, j],
                [2, j],
            ])
            endGame(board[0][j])
            return true
        }
    }

    // Check diagonals
    if (board[0][0] !== "" && board[0][0] === board[1][1] && board[1][1] === board[2][2]) {
        highlightWinningCells([
            [0, 0],
            [1, 1],
            [2, 2],
        ])
        endGame(board[0][0])
        return true
    }

    if (board[0][2] !== "" && board[0][2] === board[1][1] && board[1][1] === board[2][0]) {
        highlightWinningCells([
            [0, 2],
            [1, 1],
            [2, 0],
        ])
        endGame(board[0][2])
        return true
    }

    // Check for draw - make sure all cells are filled
    let isDraw = true
    for (let i = 0; i < 3; i++) {
        for (let j = 0; j < 3; j++) {
            if (board[i][j] === "") {
                isDraw = false
                break
            }
        }
        if (!isDraw) break
    }

    if (isDraw) {
        endGame("draw")
        return true
    }

    return false
}

// Highlight winning cells
function highlightWinningCells(cells) {
    for (const [row, col] of cells) {
        const cell = document.querySelector(`#board tr:nth-child(${row + 1}) td:nth-child(${col + 1})`)
        cell.classList.add("winning-cell")
    }
}

// End the game
function endGame(result) {
    isGameActive = false

    if (result === "draw") {
        document.getElementById("status").textContent = "Game ended in a draw!"
        draws++
        document.getElementById("draws").textContent = `Draws: ${draws}`
    } else if (result === "X") {
        document.getElementById("status").textContent = "You won!"
        playerWins++
        document.getElementById("playerWins").textContent = `Score: ${playerWins}`
    } else {
        document.getElementById("status").textContent = "AI won!"
        aiWins++
        document.getElementById("aiWins").textContent = `Score: ${aiWins}`
    }

    document.getElementById("turnIndicator").textContent = "Game Over"
}

// Reset the board UI
function resetBoardUI() {
    const cells = document.querySelectorAll("#board td")
    cells.forEach((cell) => {
        cell.textContent = ""
        cell.classList.remove("winning-cell")
        cell.style.pointerEvents = "auto"
    })
}

// Restart the game
function restartGame() {
    board = [
        ["", "", ""],
        ["", "", ""],
        ["", "", ""],
    ]
    isGameActive = true
    resetBoardUI()
    document.getElementById("status").textContent = ""
    document.getElementById("turnIndicator").textContent = "Your turn"
}

// Initialize the game when the page loads
window.onload = initGame