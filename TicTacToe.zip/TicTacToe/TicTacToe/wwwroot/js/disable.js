﻿document.addEventListener('contextmenu', function (e) {
    e.preventDefault();
});

document.onkeydown = function (e) {
    if (e.key === 'F12') {
        return false;
    }
    if (e.ctrlKey && e.shiftKey && (e.key === 'I' || e.key === 'J' || e.key === 'C' || e.key === 'U' || e.key === 'V')) {
        return false;
    }
    if (e.ctrlKey && (e.key === 'S' || e.key === 'P' || e.key === 'U' || e.key === 'C' || e.key === 'V' || e.key === 'X' || e.key === 'A')) {
        return false;
    }
};

document.addEventListener('selectstart', function (e) {
    e.preventDefault();
});

document.addEventListener('copy', function (e) {
    e.preventDefault();
});